#TournamentCreator  

Description :

Application facilitant la gestion des tournois en LAN.

##Fait  
-Gestion de la base de données et sauvegarde des tournois.
-Création du bracket par rapport aux nombres de participants au tournois.

##Pas fait
-Gestion du tournoi   

###GitLab  
[TournamentCreator](https://gitlab.com/Allegorick/tournamentcreator/-/tree/RefonteList)