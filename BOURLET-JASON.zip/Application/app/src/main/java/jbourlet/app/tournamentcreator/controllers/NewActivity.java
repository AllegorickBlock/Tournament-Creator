package jbourlet.app.tournamentcreator.controllers;

import androidx.appcompat.app.AppCompatActivity;

public class NewActivity extends AppCompatActivity {
}
