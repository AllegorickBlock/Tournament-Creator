package jbourlet.app.tournamentcreator.controllers;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import jbourlet.app.tournamentcreator.R;
import jbourlet.app.tournamentcreator.models.DatabaseHandler;
import jbourlet.app.tournamentcreator.models.Tournament;

public class TournamentActivity extends AppCompatActivity {

    private LinearLayout mRootTournament;
    private int numberPlayer;
    private int playerLeft;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tournament_activity);

        Intent mIntent = getIntent();
        Tournament mTournament = (Tournament)mIntent.getSerializableExtra("tournament");


        mRootTournament = (LinearLayout) findViewById(R.id.tournament_Root);
        numberPlayer = mTournament.getmNumberPlayer();
        playerLeft = numberPlayer;

        initBracket();

   }

   //Initialise le tournois
    private void initBracket() {
        int nbrRoundMax = numberPlayer / 2;
        for (int i = 0; i < nbrRoundMax +1; i++){
            generateRound(playerLeft);
        }

    }

    //génére les différents round du tournois dépendant du nombre de participants initiaux
    private void generateRound(int mplayerleft) {
        LinearLayout roundTournament = new LinearLayout(getApplicationContext());
        roundTournament.setOrientation(LinearLayout.VERTICAL);

        for(int i = 0;i < mplayerleft;i++){
            View tournamentView = getUserView();
            roundTournament.addView(tournamentView);
        }

        mRootTournament.addView(roundTournament);
        playerLeft = playerLeft/2;
        generateButtonMatch(playerLeft);
    }

    //Permet d'afficher les boutons qui correspond à 1 match
    private void generateButtonMatch(int playerleft) {
        if(playerleft >= 1){
            LinearLayout buttonRoundTournament = new LinearLayout(getApplicationContext());
            buttonRoundTournament.setOrientation(LinearLayout.VERTICAL);

            for (int i = 0; i < playerleft; i++){
                View buttonRoundView = getButtonRoundView();
                buttonRoundTournament.addView(buttonRoundView);
                }
            mRootTournament.addView(buttonRoundTournament);
        }
    }

    private View getButtonRoundView() {
        Button button = new Button(getApplicationContext());
        button.setText("Match");
        return button;
    }

    private View getUserView(){
        LinearLayout userCase = new LinearLayout(getApplicationContext());
        userCase.setOrientation(LinearLayout.VERTICAL);
        userCase.setPadding(25,25,25,25);
        TextView namePlayer = getTextView();

        userCase.addView(namePlayer);
        return userCase;
    }

    private TextView getTextView() {
        TextView textView = new TextView(getApplicationContext());
        textView.setText("Default");
        return textView;
    }

    private TextView getTextView(String playerName) {
        return null;
    }
}
